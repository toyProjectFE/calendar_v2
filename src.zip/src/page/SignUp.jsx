import React from "react";
import Sign from "../components/Sign/Sign";

function SignUp() {
  return (
    <>
      <Sign />
    </>
  );
}

export default SignUp;
