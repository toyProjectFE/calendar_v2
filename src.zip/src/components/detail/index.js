export { default } from "./Detail";
