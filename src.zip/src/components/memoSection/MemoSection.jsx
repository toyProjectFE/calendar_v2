import React from "react";
import styled from "styled-components";

const MemoSection = () => {
  return <Section>dgdgdgdd</Section>;
};

export default MemoSection;

const Section = styled.div`
  width: 15.62%;
  padding-right: 120px;
`;
