export { default } from "./MemoSection";
